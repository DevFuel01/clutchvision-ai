<?php
require_once 'api/config.php';

echo "=== GEMINI API DIAGNOSTIC TEST ===\n\n";
echo "API Key: " . substr(GEMINI_API_KEY, 0, 15) . "...\n";
echo "Current Model: " . GEMINI_MODEL . "\n\n";

// Test multiple models
$modelsToTest = [
    'gemini-2.0-flash',
    'gemini-2.5-flash',
    'gemini-2.5-flash-lite'
];

foreach ($modelsToTest as $model) {
    echo "Testing: $model\n";
    echo str_repeat("-", 50) . "\n";

    $url = "https://generativelanguage.googleapis.com/v1/models/$model:generateContent?key=" . GEMINI_API_KEY;

    $data = [
        "contents" => [
            [
                "parts" => [
                    ["text" => "Reply with exactly: 'Working'"]
                ]
            ]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    echo "HTTP Status: $httpCode\n";

    if ($httpCode === 200) {
        $json = json_decode($response, true);
        if (isset($json['candidates'][0]['content']['parts'][0]['text'])) {
            echo "✅ SUCCESS! Response: " . $json['candidates'][0]['content']['parts'][0]['text'] . "\n";
            echo "\n*** USE THIS MODEL: $model ***\n\n";
            break;
        }
    } else {
        $json = json_decode($response, true);
        if (isset($json['error']['message'])) {
            echo "❌ Error: " . $json['error']['message'] . "\n";
        } else {
            echo "Response: " . substr($response, 0, 200) . "\n";
        }
    }

    curl_close($ch);
    echo "\n";
    sleep(2); // Wait between tests
}
