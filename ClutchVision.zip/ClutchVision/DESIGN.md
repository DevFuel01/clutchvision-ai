# ClutchVision AI - Design & Specification

## 1. System Architecture Overview
**Concept**: A hybrid edge-cloud processing system where raw signal processing (Audio/Video) occurs in the browser to reduce latency and server load, while valid "events" are sent to the PHP backend for storage and batch-processed by Generative AI for semantic understanding.

*   **Frontend (The Eye)**: Vanilla JS, HTML5 Video, Web Audio API. 
    *   Responsibilities: Video playback, Real-time audio analysis (Crowd Noise), Pixel diffing (Motion Intensity), Logic scoring, API transmission, UI Visualization.
*   **Backend (The Brain)**: PHP 8+, Apache.
    *   Responsibilities: REST API endpoints, Database orchestration, AI API Bridge.
*   **Database (The Memory)**: MySQL.
    *   Responsibilities: Relational storage of Games, Time-series Events, and AI-generated content.
*   **AI Engine (The Coach)**: Google Gemini (via API).
    *   Responsibilities: Analyzing numerical and metadata patterns to determine "User Intensity" vs "Game Context", generating textual summaries and selecting top clips.

## 2. Frontend Workflow Description
1.  **Initialization**: User uploads `game_footage.mp4`. Browser loads video into `<video>` tag (hidden or visible).
2.  **Analysis Loop (run every 1000ms during playback)**:
    *   **Audio**: Web Audio API `AnalyserNode` captures audio buffer. Calculate RMS (Root Mean Square) to determine decibel level (normalize 0-100).
    *   **Video**: Draw current frame to hidden `<canvas>`. Compare pixel buffer with previous frame. Calculate % of changed pixels (Motion Intensity).
    *   **Scoring**: Apply formula: `Score = (Noise * 0.5) + (Motion * 0.3) + (ScoreUpdate * 0.2)`. (Note: ScoreUpdate detection requires OCR or manual trigger in MVP, defaulting to 0 for auto-mode).
    *   **Thresholding**: If `Score > Threshold` (e.g., 60), mark as "Potential Highlight".
3.  **Data Transmission**: Events are buffered and sent to `POST /api/events` in batches every 10 seconds to minimize network overhead.
4.  **AI Trigger**: When analysis is complete, User clicks "Analyze Game". Frontend calls `POST /api/ai/process`.
5.  **Result Rendering**: Frontend fetches results from `GET /api/games/{id}` and renders the Highlight Reel and AI Commentary.

## 3. Backend API Structure
All endpoints return JSON.

*   `POST /api/game/create`
    *   Input: `{ "title": "Lakers vs Warriors", "date": "2023-10-25" }`
    *   Output: `{ "success": true, "game_id": 101 }`

*   `POST /api/events/log`
    *   Input: `{ "game_id": 101, "events": [ { "timestamp": 12.5, "quarter": 1, "crowd_noise": 85, "motion_intensity": 40, "excitement_score": 54.5 }, ... ] }`
    *   Output: `{ "success": true, "saved_count": 5 }`

*   `POST /api/ai/analyze`
    *   Input: `{ "game_id": 101 }`
    *   Logic: Fetches high-score events from DB -> Formats Prompt -> Calls Gemini API -> Saves response to `highlights` and `ai_summaries` tables.
    *   Output: `{ "success": true }`

*   `GET /api/game/{id}/results`
    *   Output: `{ "game": {...}, "highlights": [...], "summary": {...} }`

## 4. SQL Schema

```sql
CREATE TABLE games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    timestamp DECIMAL(10, 2) NOT NULL, -- Seconds from start
    quarter INT DEFAULT 1,
    crowd_noise_level INT NOT NULL, -- 0-100
    motion_intensity INT NOT NULL, -- 0-100
    scoring_event TINYINT(1) DEFAULT 0,
    excitement_score DECIMAL(5, 2) NOT NULL,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
    INDEX (game_id),
    INDEX (excitement_score)
);

CREATE TABLE highlights (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL, -- Added strictly for easier querying, though reachable via event_id
    event_time DECIMAL(10, 2) NOT NULL,
    label VARCHAR(100) NOT NULL, -- e.g. "Dunk", "Three Pointer"
    explanation TEXT,
    rank_order INT NOT NULL, -- 1-5
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
);

CREATE TABLE ai_summaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    summary_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
);
```

## 5. AI Prompt Logic (Gemini)

**System Instruction**:
"You are ClutchVision, an expert basketball analyst engine. You analyze timeseries data from game sensors to identify the narrative arc of a match."

**User Prompt**:
```text
Analyze the following telemetry data from a basketball game. 
Data Format: [Time(sec) | Qtr | CrowdNoise(0-100) | Motion(0-100) | CalcScore]

Events:
{EVENTS_JSON_STRING}

Task 1: Identify the TOP 5 highlights based on the Calculated Score, but prioritize moments where CrowdNoise and Motion peak simultaneously.
Task 2: Identify any "Momentum Shifts" (sustained periods of rising intensity).
Task 3: Write a 3-sentence broadcast summary of the game's flow.

Output strictly in this JSON format:
{
  "highlights": [
    { "time": 120.5, "label": "Fast Break Dunk", "explanation": "Sudden spiked motion followed by eruption in crowd noise.", "rank": 1 }
  ],
  "momentum_shifts": [ "Q4 2:00 - Strong defensive stand leading to transition offense" ],
  "summary": "The game started slow but intensity spiked in Q3..."
}
```

## 6. Sample JSON Data Flow

**Input (From Frontend to Backend):**
```json
{
  "game_id": 42,
  "events": [
    { "timestamp": 245.2, "quarter": 1, "crowd_noise": 45, "motion_intensity": 30, "excitement_score": 31.5 },
    { "timestamp": 246.5, "quarter": 1, "crowd_noise": 95, "motion_intensity": 88, "excitement_score": 88.9 }
  ]
}
```

**Output (From AI to Database):**
```json
{
  "highlights": [
    {
      "time": 246.5,
      "label": "Crowd-Erupting Play",
      "explanation": "Simultaneous peak in motion (88) and crowd volume (95) indicates a significant scoring play or defensive stop.",
      "rank": 1
    }
  ],
  "summary": "A high-energy sequence detected in Quarter 1 driven by aggressive transition play."
}
```

## 7. Demo Flow Explanation
1.  **Landing**: User sees "ClutchVision AI" dashboard.
2.  **Upload**: User drags & drops a 5-minute clip of a game.
3.  **Processing**: The video plays at 1x (or 5x speed for demo). A real-time graph overlays the video showing "Excitement Level".
4.  **Detection Visuals**: When the graph spikes into the "Red Zone" (>80), a marker drops on the timeline labeled "Event Detected".
5.  **Completion**: Video ends. "Calculating Insights..." spinner appears.
6.  **Reveal**: AI Summary types out like a typewriter. Top 5 Cards appear below.
7.  **Interaction**: User clicks Highlight Card #1. Video player instantly jumps to `timestamp - 5s` and plays the dunk.
