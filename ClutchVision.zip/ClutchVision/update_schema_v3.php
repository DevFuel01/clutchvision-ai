<?php
require_once 'db.php';

try {
    // Add player_tags column to highlights table
    $sql = "
        ALTER TABLE highlights
        ADD COLUMN player_tags TEXT DEFAULT '';
    ";

    $pdo->exec($sql);
    echo "Schema updated successfully: Added player_tags to highlights table.";
} catch (PDOException $e) {
    echo "Error updating schema: " . $e->getMessage();
}
