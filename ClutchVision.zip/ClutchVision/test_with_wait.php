<?php
require_once 'api/config.php';

echo "Waiting 60 seconds for rate limit to reset...\n";
sleep(60);

echo "Testing Gemini API Connection...\n\n";

$url = "https://generativelanguage.googleapis.com/v1/models/" . GEMINI_MODEL . ":generateContent?key=" . GEMINI_API_KEY;

$data = [
    "contents" => [
        [
            "parts" => [
                ["text" => "Say 'ClutchVision AI works!' in 4 words."]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

echo "HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    $json = json_decode($response, true);
    if (isset($json['candidates'][0]['content']['parts'][0]['text'])) {
        echo "✅ SUCCESS! AI says: " . $json['candidates'][0]['content']['parts'][0]['text'] . "\n";
        echo "\nYour API key works! The rate limit has reset.\n";
        echo "You can now use the app, but wait 60+ seconds between analyses.\n";
    }
} else {
    echo "Response: " . substr($response, 0, 500) . "\n";
    echo "\n❌ Still rate limited. You may need to:\n";
    echo "1. Wait longer (try 5 minutes)\n";
    echo "2. Upgrade to paid tier\n";
    echo "3. Use a different API key\n";
}

curl_close($ch);
