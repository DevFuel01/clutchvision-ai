const app = {
    // Config
    apiBase: 'api',
    config: {
        analysisInterval: 250, // ms
        batchInterval: 5000,   // ms
        threshold: 50,         // Min score to log
        pixelSkip: 10          // Skip pixels for perf
    },

    // State
    state: {
        gameId: null,
        isAnalyzing: false,
        audioCtx: null,
        analyser: null,
        source: null,
        prevFrameData: null,
        eventBuffer: [],
        eventsLog: [], // Local copy for visualization
        allHighlights: [], // Copy for filtering
        filterPlayer: null,
        selectedCaption: null,
        userTier: 'Free',
        balance: 0.00
    },

    // DOM Elements
    ui: {},

    init() {
        this.cacheDOM();
        this.bindEvents();
        this.log("System Ready. Waiting for footage...");
    },




    cacheDOM() {
        this.ui = {
            uploadArea: document.getElementById('uploadArea'),
            videoInput: document.getElementById('videoInput'),
            gameDateInput: document.getElementById('gameDateInput'),
            videoWrapper: document.getElementById('videoWrapper'),
            video: document.getElementById('gameVideo'),
            
            // Stats
            noiseBar: document.getElementById('noiseBar'),
            noiseVal: document.getElementById('noiseVal'),
            motionBar: document.getElementById('motionBar'),
            motionVal: document.getElementById('motionVal'),
            scoreVal: document.getElementById('scoreVal'),
            overlay: document.getElementById('analysisOverlay'),

            // Timeline & Controls
            timelineContainer: document.getElementById('timelineContainer'),
            timelineTrack: document.getElementById('timelineTrack'),
            controlsArea: document.getElementById('controlsArea'),
            startBtn: document.getElementById('startAnalysisBtn'),
            genReportBtn: document.getElementById('generateReportBtn'),
            quarterSelect: document.getElementById('quarterSelect'),

            // Processing
            canvas: document.getElementById('procCanvas'),
            ctx: document.getElementById('procCanvas').getContext('2d', { willReadFrequently: true }),

            // Output
            console: document.getElementById('consoleOutput'),
            resultsPanel: document.getElementById('resultsPanel'),
            aiSummary: document.getElementById('aiSummaryText'),
            highlights: document.getElementById('highlightsContainer'),
            scoringBtn: document.getElementById('scoringEventBtn'),
            exportBtn: document.getElementById('exportBtn'),
            
            // Library
            libraryBtn: document.getElementById('libraryBtn'),
            libraryModal: document.getElementById('libraryModal'),
            closeModalBtn: document.getElementById('closeModalBtn'),
            
            // View Mode & Filters
            viewModeSelect: document.getElementById('viewModeSelect'),
            filterQuarter: document.getElementById('filterQuarter'),
            filterScore: document.getElementById('filterScore'),
            filterType: document.getElementById('filterType'),
            filtersBar: document.getElementById('filtersBar'),
            
            // Live
            liveCamBtn: document.getElementById('liveCamBtn'),
            
            // Player Heat
            playerHeatStats: document.getElementById('playerHeatStats'),
            playerList: document.getElementById('playerList'),

            // Social Hub
            socialModal: document.getElementById('socialModal'),
            closeSocialBtn: document.getElementById('closeSocialBtn'),
            captionOptions: document.getElementById('captionOptions'),
            publishTikTokBtn: document.getElementById('publishTikTokBtn'),
            publishReelsBtn: document.getElementById('publishReelsBtn'),
            publishProgress: document.getElementById('publishProgress'),
            publishProgressBar: document.getElementById('publishProgressBar'),
            publishStatus: document.getElementById('publishStatus'),
            socialPreviewVideo: document.getElementById('socialPreviewVideo'),

            // Broadcaster
            liveOverlay: document.getElementById('liveOverlay'),
            commentaryAssistBox: document.getElementById('commentaryAssistBox'),
            commentaryCues: document.getElementById('commentaryCues'),

            // League Stats
            leagueModal: document.getElementById('leagueModal'),
            leagueStatsBtn: document.getElementById('leagueStatsBtn'),
            closeLeagueBtn: document.getElementById('closeLeagueBtn'),
            seasonTotalScore: document.getElementById('seasonTotalScore'),
            seasonAvgScore: document.getElementById('seasonAvgScore'),
            seasonHighlights: document.getElementById('seasonHighlights'),
            gameComparisonChart: document.getElementById('gameComparisonChart'),
            seasonLeadersList: document.getElementById('seasonLeadersList'),
            seasonTrendChart: document.getElementById('seasonTrendChart'),

            // Monetization
            pricingModal: document.getElementById('pricingModal'),
            goProBtn: document.getElementById('goProBtn'),
            closePricingBtn: document.getElementById('closePricingBtn'),
            earningsDashboard: document.getElementById('earningsDashboard'),
            userTierBadge: document.getElementById('userTierBadge'),
            estBalance: document.getElementById('estBalance')
        };
    },

    bindEvents() {
        this.ui.uploadArea.addEventListener('click', (e) => {
            // Prevent click if clicking the button (buttons are inside uploadArea)
            if (e.target !== this.ui.liveCamBtn && !this.ui.liveCamBtn.contains(e.target)) {
               this.ui.videoInput.click();
            }
        });
        
        if (this.ui.liveCamBtn) {
            this.ui.liveCamBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.startLiveStream();
            });
        }

        this.ui.videoInput.addEventListener('change', (e) => this.handleUpload(e));
        this.ui.startBtn.addEventListener('click', () => this.startAnalysis());
        this.ui.genReportBtn.addEventListener('click', () => this.generateReport());
        
        // Scoring & Export
        this.ui.scoringBtn.addEventListener('click', () => this.triggerScoringEvent());
        if (this.ui.exportBtn) {
            this.ui.exportBtn.addEventListener('click', () => this.copyToClipboard());
        }

        if (this.ui.libraryBtn) {
            this.ui.libraryBtn.addEventListener('click', () => this.fetchGames());
            this.ui.closeModalBtn.addEventListener('click', () => {
                this.ui.libraryModal.classList.add('hidden');
            });
        }
        
        // View Mode
        if (this.ui.viewModeSelect) {
            this.ui.viewModeSelect.addEventListener('change', (e) => {
                const isHidden = this.ui.resultsPanel.classList.contains('hidden');
                this.ui.resultsPanel.className = 'results-panel mode-' + e.target.value;
                if (isHidden) this.ui.resultsPanel.classList.add('hidden');
            });
            // Set initial mode
            this.ui.resultsPanel.classList.add('mode-creator');
        }

        // Filters
        [this.ui.filterQuarter, this.ui.filterScore, this.ui.filterType].forEach(el => {
            if (el) el.addEventListener('change', () => this.applyFilters());
        });
        
        // Social Hub
        if (this.ui.closeSocialBtn) {
            this.ui.closeSocialBtn.addEventListener('click', () => {
                this.ui.socialModal.classList.add('hidden');
            });
        }
        if (this.ui.publishTikTokBtn) {
            this.ui.publishTikTokBtn.addEventListener('click', () => this.simulatePublish('TikTok'));
        }
        if (this.ui.publishReelsBtn) {
            this.ui.publishReelsBtn.addEventListener('click', () => this.simulatePublish('Reels'));
        }

        if (this.ui.leagueStatsBtn) {
            this.ui.leagueStatsBtn.addEventListener('click', () => this.openLeagueDashboard());
            this.ui.closeLeagueBtn.addEventListener('click', () => this.ui.leagueModal.classList.add('hidden'));
        }

        // Monetization
        if (this.ui.goProBtn) {
            this.ui.goProBtn.addEventListener('click', () => this.ui.pricingModal.classList.remove('hidden'));
            this.ui.closePricingBtn.addEventListener('click', () => this.ui.pricingModal.classList.add('hidden'));
        }

        // Setup Batch Sender
        setInterval(() => this.flushEvents(), this.config.batchInterval);

        // Set Default Date
        if (this.ui.gameDateInput) {
            this.ui.gameDateInput.value = new Date().toISOString().split('T')[0];
        }
    },

    async copyToClipboard() {
        if (!this.state.gameId) return;
        
        const summary = this.ui.aiSummary.innerText;
        const cards = document.querySelectorAll('.highlight-card');
        
        let text = "🏀 CLUTCHVISION AI REPORT 🏀\n\n";
        text += `Summary: ${summary}\n\n`;
        text += "🔥 TOP HIGHLIGHTS:\n";
        
        cards.forEach(card => {
            const time = card.querySelector('.highlight-time').innerText;
            const label = card.querySelector('.highlight-label').innerText;
            text += `• ${time} - ${label}\n`;
        });
        
        text += "\n#ClutchVision #BasketballAI #GameAnalysis";

        try {
            await navigator.clipboard.writeText(text);
            this.ui.exportBtn.innerText = "✅ Copied!";
            setTimeout(() => this.ui.exportBtn.innerText = "📋 Copy Text", 2000);
        } catch (err) {
            this.log("Failed to copy: " + err, "alert");
        }
    },

    triggerScoringEvent() {
        const now = this.ui.video.currentTime;
        this.log(`Manual Scoring Event Triggered at ${now.toFixed(1)}s`, "success");
        // Force log regardless of threshold
        this.logEvent(now, 100, 100, 100, true);
    },

    log(msg, type = 'normal') {
        const div = document.createElement('div');
        div.className = `log-entry ${type}`;
        div.innerHTML = `> [${new Date().toLocaleTimeString()}] ${msg}`;
        this.ui.console.prepend(div);
    },

    async handleUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        this.log(`File Loaded: ${file.name} (${(file.size/1024/1024).toFixed(2)} MB)`);
        
        const url = URL.createObjectURL(file);
        this.ui.video.src = url;
        
        // Wait for metadata to get duration
        this.ui.video.onloadedmetadata = async () => {
            const duration = Math.round(this.ui.video.duration);
            const gameDate = this.ui.gameDateInput.value || new Date().toISOString().split('T')[0];
            
            this.log(`Video Metadata: ${duration}s duration, Date: ${gameDate}`);

            // Create Game Session
            try {
                const resp = await fetch(`${this.apiBase}/game_create.php`, {
                    method: 'POST',
                    body: JSON.stringify({ 
                        title: file.name.split('.')[0],
                        game_date: gameDate,
                        duration: duration
                    })
                });
                const data = await resp.json();
                if (data.success) {
                    this.state.gameId = data.game_id;
                    this.log(`Game Session Created: ID #${this.state.gameId}`);
                    
                    // Show Video UI
                    this.ui.uploadArea.classList.add('hidden');
                    this.ui.videoWrapper.classList.remove('hidden');
                    this.ui.controlsArea.classList.remove('hidden');
                } else {
                    throw new Error(data.error || "Unknown server error");
                }
            } catch (err) {
                this.log("Error creating game session: " + err, "alert");
                alert("❌ Database Error: Failed to initialize game session.\n\nDetails: " + err.message + "\n\nIf this is a deployment, please check your database schema matches database.sql.");
            }
        };
    },

    async startLiveStream() {
        try {
            this.log("Requesting Webcam Access...");
            const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            this.ui.video.srcObject = stream;
            
            this.log("🔴 Live Stream Connected!");
            
            // Create a "Live Session" game
            const gameDate = this.ui.gameDateInput.value || new Date().toISOString().split('T')[0];
            
            try {
                const resp = await fetch(`${this.apiBase}/game_create.php`, {
                    method: 'POST',
                    body: JSON.stringify({ 
                        title: "Live Game - " + new Date().toLocaleTimeString(),
                        game_date: gameDate,
                        duration: 0 // Unknown duration
                    })
                });
                
                const data = await resp.json();
                if (data.success) {
                    this.state.gameId = data.game_id;
                    this.log(`Live Session ID #${this.state.gameId} Created`);
                    
                    this.ui.uploadArea.classList.add('hidden');
                    this.ui.videoWrapper.classList.remove('hidden');
                    this.ui.controlsArea.classList.remove('hidden');
                    
                    // Switch to live mode UI?
                    this.ui.video.play();
                    this.startAnalysis();
                } else {
                    throw new Error(data.error || "Unknown server error");
                }
            } catch (err) {
                this.log("Live Access Error: " + err, "alert");
                alert("❌ Live Camera Error: Failed to initialize session.\n\nDetails: " + err.message);
            }

        } catch (err) {
            this.log("Error accessing camera: " + err.message, "alert");
        }
    },

    startAnalysis() {
        if (this.state.isAnalyzing) return;
        
        this.state.isAnalyzing = true;
        this.ui.video.play();
        this.ui.startBtn.classList.add('hidden');
        this.ui.timelineContainer.classList.remove('hidden');
        this.log("Real-time Analysis Engine STARTED.");

        this.setupAudio();
        this.analysisLoop();
    },

    setupAudio() {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.state.audioCtx = new AudioContext();
        this.state.analyser = this.state.audioCtx.createAnalyser();
        this.state.analyser.fftSize = 256;
        
        this.state.source = this.state.audioCtx.createMediaElementSource(this.ui.video);
        this.state.source.connect(this.state.analyser);
        this.state.source.connect(this.state.audioCtx.destination);
    },

    analysisLoop() {
        if (this.ui.video.paused || this.ui.video.ended) {
            if (this.ui.video.ended) this.finishAnalysis();
            else requestAnimationFrame(() => this.analysisLoop());
            return;
        }

        // 1. Audio Level
        const dataArray = new Uint8Array(this.state.analyser.frequencyBinCount);
        this.state.analyser.getByteFrequencyData(dataArray);
        
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
        const avg = sum / dataArray.length;
        const noiseLevel = Math.min(100, (avg / 128) * 100); // Normalize roughly

        // 2. Video Motion
        let motionLevel = 0;
        const w = 160; // Low res for perf
        const h = 90;
        
        this.ui.ctx.drawImage(this.ui.video, 0, 0, w, h);
        const frame = this.ui.ctx.getImageData(0, 0, w, h);
        
        if (this.state.prevFrameData) {
            let diff = 0;
            const data = frame.data;
            const prev = this.state.prevFrameData.data;
            const skip = 4 * this.config.pixelSkip; 

            let pixelsChecked = 0;

            for (let i = 0; i < data.length; i += skip) {
                // Simple grayscale diff
                const r = Math.abs(data[i] - prev[i]);
                const g = Math.abs(data[i+1] - prev[i+1]);
                const b = Math.abs(data[i+2] - prev[i+2]);
                if ((r+g+b) > 50) diff++;
                pixelsChecked++;
            }
            
            motionLevel = Math.min(100, (diff / pixelsChecked) * 100 * 5); // Amplify diff
        }
        
        this.state.prevFrameData = frame;

        // 3. Score
        // Weight: Noise 60%, Motion 40%
        const score = (noiseLevel * 0.6) + (motionLevel * 0.4); 

        // 4. Update UI
        this.ui.noiseBar.style.width = `${noiseLevel}%`;
        this.ui.noiseVal.innerText = Math.round(noiseLevel);
        
        this.ui.motionBar.style.width = `${motionLevel}%`;
        this.ui.motionVal.innerText = Math.round(motionLevel);
        
        this.ui.scoreVal.innerText = score.toFixed(1);

        if (score > 80) {
            this.ui.scoreVal.style.color = 'var(--accent-secondary)';
            this.ui.scoreVal.style.textShadow = '0 0 10px red';
        } else {
            this.ui.scoreVal.style.color = 'var(--accent-secondary)';
            this.ui.scoreVal.style.textShadow = 'none';
        }

        // 5. Log Potential Event
        if (score > this.config.threshold) {
            // throttle events: only log if 2s passed since interesting event
            const now = this.ui.video.currentTime;
            const last = this.state.eventsLog[this.state.eventsLog.length - 1];
            
            if (!last || (now - last.timestamp > 2)) {
                this.logEvent(now, noiseLevel, motionLevel, score);
            }
        }

        requestAnimationFrame(() => this.analysisLoop());
    },

    logEvent(time, noise, motion, score) {
        const event = {
            timestamp: time,
            quarter: 1, // hardcoded for MVP
            crowd_noise: Math.round(noise),
            motion_intensity: Math.round(motion),
            excitement_score: parseFloat(score.toFixed(2)),
            scoring_event: false
        };

        this.state.eventBuffer.push(event);
        this.state.eventsLog.push(event);

        // Add Marker
        const pct = (time / this.ui.video.duration) * 100;
        const marker = document.createElement('div');
        marker.className = 'event-marker';
        marker.style.left = `${pct}%`;
        marker.onclick = () => this.ui.video.currentTime = time;
        this.ui.timelineTrack.appendChild(marker);
        
        this.log(`Event detected at ${time.toFixed(1)}s (Score: ${score.toFixed(1)})`, "alert");

        // Broadcaster Overlays & Assist
        if (score > 90) {
            this.triggerLiveOverlay('clutch', '🔥 CLUTCH MOMENT!');
            this.updateCommentaryAssist(score, motion, noise);
        } else if (score > 80) {
            this.triggerLiveOverlay('momentum', '📈 MOMENTUM SHIFT');
            this.updateCommentaryAssist(score, motion, noise);
        } else if (motion > 80) {
            this.triggerLiveOverlay('energy', '⚡ HIGH ENERGY');
            this.updateCommentaryAssist(score, motion, noise);
        }

        // Creator Earnings
        this.updateEarnings(score);

        // Instant Push for Live Highlights
        if (score > 85) {
            this.renderLiveHighlight(time, score, noise, motion);
        }
    },

    renderLiveHighlight(time, score, noise, motion) {
        // Create the container if it's empty
        if (this.ui.highlights.innerHTML.includes('No matching highlights') || this.ui.highlights.innerText === '') {
            this.ui.highlights.innerHTML = '';
        }

        const el = document.createElement('div');
        el.className = 'highlight-card live-push';
        el.style.borderLeft = '4px solid #ff4444';
        el.style.animation = 'slideIn 0.5s ease-out';
        
        el.innerHTML = `
            <div class="highlight-rank blink" style="color:#ff4444">🔴 LIVE</div>
            <div class="highlight-time">${this.formatTime(time)}</div>
            <span class="highlight-label">Wait for AI Analysis...</span>
            <p style="font-size:0.8rem; color:var(--text-muted)">
                Potential Game-Breaker! Score: ${score.toFixed(1)}
            </p>
        `;
        
        el.onclick = () => {
             this.ui.video.currentTime = Math.max(0, time - 5);
             this.ui.video.play();
        };

        // Prepend to top
        this.ui.highlights.prepend(el);
    },

    async flushEvents() {
        if (this.state.eventBuffer.length === 0 || !this.state.gameId) return;

        const payload = {
            game_id: this.state.gameId,
            events: [...this.state.eventBuffer]
        };
        
        this.state.eventBuffer = []; // Clear buffer

        try {
            await fetch(`${this.apiBase}/events_log.php`, {
                method: 'POST',
                body: JSON.stringify(payload)
            });
        } catch (e) {
            console.error("Failed to sync events");
        }
    },

    finishAnalysis() {
        this.state.isAnalyzing = false;
        this.log("Game Ended. Finalizing data...");
        this.flushEvents(); // Final flush
        
        this.ui.genReportBtn.classList.remove('hidden');
    },

    async generateReport() {
        this.ui.genReportBtn.disabled = true;
        this.ui.genReportBtn.innerText = "Processing...";
        this.log("Contacting AI Engine for narrative generation...");

        try {
            // Trigger AI
            const res = await fetch(`${this.apiBase}/ai_analyze.php`, {
                method: 'POST',
                body: JSON.stringify({ game_id: this.state.gameId })
            });
            const data = await res.json();
            
            if (data.success) {
                this.log("AI Analysis Complete. Retrieving artifacts...");
                await this.renderResults();
            } else {
                this.log("AI Error: " + data.error, "alert");
            }
        
        } catch (e) {
            this.log("Network Error: " + e.message, "alert");
        }
        
        this.ui.genReportBtn.innerText = "Regenerate Report";
        this.ui.genReportBtn.disabled = false;
    },

    async renderResults() {
        const res = await fetch(`${this.apiBase}/game_results.php?id=${this.state.gameId}`);
        const data = await res.json();
        
        if (!data.success) return;

        this.ui.resultsPanel.classList.remove('hidden');
        
        // Typewriter Effect for Summary
        if (data.summary && data.summary.summary_text) {
             this.typeWriter(data.summary.summary_text, this.ui.aiSummary);
        }

        // Render Momentum Shifts
        const momentumContainer = document.getElementById('momentumContainer');
        if (data.momentum_shifts && data.momentum_shifts.length > 0) {
            momentumContainer.innerHTML = '<h3>Momentum Alerts</h3>';
            momentumContainer.classList.remove('hidden');
            
            data.momentum_shifts.forEach(msg => {
                const el = document.createElement('div');
                el.className = 'momentum-alert';
                el.innerHTML = `<span class="alert-icon">⚡</span> ${msg}`;
                momentumContainer.appendChild(el);
            });
        }

        // Check if filters bar needs to be shown
        if (data.highlights && data.highlights.length > 0) {
            this.state.allHighlights = data.highlights;
            this.ui.filtersBar.classList.remove('hidden');
            this.ui.playerHeatStats.classList.remove('hidden'); // Show player stats
            this.applyFilters();
            this.renderPlayerHeatMap(); // Calculate top players
        } else {
             this.ui.highlights.innerHTML = '<p style="color:var(--text-muted)">No highlights found.</p>';
        }
    },

    applyFilters() {
        if (!this.state.allHighlights) return;
        
        // Reset player filter if needed (optional, or keeping it separate)
        
        const q = this.ui.filterQuarter.value;
        const s = this.ui.filterScore.value;
        const t = this.ui.filterType.value;

        const filtered = this.state.allHighlights.filter(h => {
            // Player Filter (Check if filtering by player)
            if (this.state.filterPlayer && (!h.player_tags || !h.player_tags.includes(this.state.filterPlayer))) return false;

            // Quarter Filter (default to 1 if missing)
            const hQ = h.quarter || 1;
            if (q !== 'all' && hQ != q) return false;

            // Score Filter
            const hS = h.score || 0;
            if (s !== 'all' && hS < parseInt(s)) return false;

            // Type Filter
            if (t !== 'all' && !h.label.includes(t)) return false;

            return true;
        });

        this.renderHighlightsList(filtered);
    },

    renderHighlightsList(list) {
        this.ui.highlights.innerHTML = '';
        if (list.length === 0) {
            this.ui.highlights.innerHTML = '<p style="color:var(--text-muted)">No matching highlights.</p>';
            return;
        }

        list.forEach(hl => {
            const el = document.createElement('div');
            el.className = 'highlight-card';
            
            // Render Tags
            let tagsHtml = '';
            if (hl.player_tags) {
                hl.player_tags.split(',').forEach(tag => {
                    const t = tag.trim();
                    if(t) tagsHtml += `<span class="player-tag" onclick="window.app.filterByPlayer('${t}', event)">${t}</span>`;
                });
            }

            el.innerHTML = `
                <div class="highlight-rank">#${hl.rank_order}</div>
                <div class="highlight-time">Q${hl.rank_order} • ${this.formatTime(hl.event_time)}</div>
                <span class="highlight-label">${hl.label}</span>
                <p style="font-size:0.8rem; color:var(--text-muted)">${hl.explanation}</p>
                
                <div style="margin-top: 8px; display: flex; flex-wrap: wrap; gap: 5px; align-items: center;">
                    ${tagsHtml}
                    <button class="add-tag-btn" onclick="window.app.addTag(${hl.id}, event)">+</button>
                    <button class="share-btn" onclick="window.app.openSocialHub(${hl.id}, event)" title="Social Hub">📱</button>
                </div>

                <div style="font-size:0.7rem; color:var(--accent-secondary); margin-top:5px;">🔥 Score: ${hl.score || 'N/A'}</div>
            `;
            el.onclick = (e) => {
                // Ignore clicks on tags/buttons
                if (e.target.tagName === 'BUTTON' || e.target.classList.contains('player-tag')) return;
                
                const startTime = Math.max(0, hl.event_time - 5);
                const duration = 10; // 10 second highlight clip
                
                this.ui.video.currentTime = startTime;
                this.ui.video.play();

                // Stop playback after duration
                const stopPlayback = () => {
                    if (this.ui.video.currentTime >= startTime + duration) {
                        this.ui.video.pause();
                        this.ui.video.removeEventListener('timeupdate', stopPlayback);
                    }
                };
                
                // Remove previous listener if exists (to avoid multiple pauses)
                if (this._currentStopListener) {
                    this.ui.video.removeEventListener('timeupdate', this._currentStopListener);
                }
                this._currentStopListener = stopPlayback;
                this.ui.video.addEventListener('timeupdate', stopPlayback);
            };
            this.ui.highlights.appendChild(el);
        });
    },

    async addTag(id, e) {
        e.stopPropagation();
        const tags = prompt("Enter player name(s) or number (comma separated):");
        if (!tags) return;

        try {
            const res = await fetch(`${this.apiBase}/save_tags.php`, {
                method: 'POST',
                body: JSON.stringify({ highlight_id: id, tags: tags })
            });
            const data = await res.json();
            
            if (data.success) {
                // Update local state
                const h = this.state.allHighlights.find(x => x.id == id);
                if (h) h.player_tags = data.tags;
                
                this.applyFilters(); // Re-render
                this.renderPlayerHeatMap(); // Update Heat Map
            }
        } catch (err) {
            alert("Error saving tags: " + err);
        }
    },

    filterByPlayer(player, e) {
        if (e) e.stopPropagation();
        
        if (this.state.filterPlayer === player) {
            this.state.filterPlayer = null; // Toggle off
        } else {
            this.state.filterPlayer = player;
        }
        this.applyFilters();
    },

    renderPlayerHeatMap() {
        if (!this.state.allHighlights) return;

        const playerScores = {};

        this.state.allHighlights.forEach(hl => {
            if (hl.player_tags) {
                hl.player_tags.split(',').forEach(t => {
                    const tag = t.trim();
                    if (!tag) return;
                    
                    if (!playerScores[tag]) playerScores[tag] = 0;
                    playerScores[tag] += parseFloat(hl.score || 0);
                });
            }
        });

        // unique players sorted by score
        const sorted = Object.keys(playerScores).sort((a,b) => playerScores[b] - playerScores[a]);
        
        this.ui.playerList.innerHTML = '';
        if (sorted.length === 0) {
            this.ui.playerList.innerHTML = '<span style="color:var(--text-muted); font-size:0.8rem;">No tagged players yet. Add tags to highlights!</span>';
            return;
        }

        sorted.forEach((p, index) => {
            const score = playerScores[p].toFixed(0);
            const row = document.createElement('div');
            row.className = 'player-row';
            row.style.cursor = 'pointer';
            row.style.display = 'flex';
            row.style.justifyContent = 'space-between';
            row.style.padding = '4px 8px';
            row.style.background = this.state.filterPlayer === p ? 'var(--accent-primary-dim)' : 'transparent';
            row.style.borderRadius = '4px';
            
            row.innerHTML = `
                <span>${index+1}. ${p}</span>
                <span style="color:var(--accent-secondary)">🔥 ${score}</span>
            `;
            row.onclick = () => {
                this.filterByPlayer(p);
                this.renderPlayerHeatMap(); // Update selection style
            };
            this.ui.playerList.appendChild(row);
        });
    },

    async openSocialHub(id, e) {
        if (e) e.stopPropagation();
        this.ui.socialModal.classList.remove('hidden');
        this.ui.captionOptions.innerHTML = '<div class="caption-loading">🤖 AI is drafting the perfect post...</div>';
        this.ui.publishProgress.classList.add('hidden');
        
        // Setup Preview
        const hl = this.state.allHighlights.find(x => x.id == id);
        if (hl && this.ui.socialPreviewVideo) {
            this.ui.socialPreviewVideo.src = this.ui.video.src;
            this.ui.socialPreviewVideo.currentTime = Math.max(0, hl.event_time - 2);
            this.ui.socialPreviewVideo.play();
        }

        try {
            const res = await fetch(`${this.apiBase}/generate_caption.php`, {
                method: 'POST',
                body: JSON.stringify({ highlight_id: id })
            });
            const data = await res.json();
            
            if (data.success) {
                this.renderCaptionOptions(data.captions);
            } else {
                this.ui.captionOptions.innerHTML = `<p style="color:red">Error: ${data.error}</p>`;
            }
        } catch (err) {
            this.ui.captionOptions.innerHTML = `<p style="color:red">Failed to load captions.</p>`;
        }
    },

    renderCaptionOptions(captions) {
        this.ui.captionOptions.innerHTML = '';
        const platforms = ['tiktok', 'reels', 'x'];
        
        platforms.forEach(p => {
            if (!captions[p]) return;
            const div = document.createElement('div');
            div.className = 'caption-card';
            div.innerHTML = `<strong>${p.toUpperCase()} Style:</strong><br>${captions[p]}`;
            div.onclick = () => {
                document.querySelectorAll('.caption-card').forEach(c => c.classList.remove('selected'));
                div.classList.add('selected');
                this.state.selectedCaption = captions[p];
            };
            this.ui.captionOptions.appendChild(div);
        });
        
        // Select first by default
        this.ui.captionOptions.firstChild.click();
    },

    simulatePublish(platform) {
        if (!this.state.selectedCaption) {
            alert("Please select a caption first!");
            return;
        }

        this.ui.publishProgress.classList.remove('hidden');
        this.ui.publishProgressBar.style.width = '0%';
        this.ui.publishStatus.innerText = `Preparing upload to ${platform}...`;
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 30;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                this.ui.publishProgressBar.style.width = '100%';
                this.ui.publishStatus.innerText = `✅ Successfully Published to ${platform}!`;
                this.log(`Social Post Published to ${platform}`, "success");
                
                setTimeout(() => {
                    this.ui.socialModal.classList.add('hidden');
                }, 2000);
            } else {
                this.ui.publishProgressBar.style.width = `${progress}%`;
                this.ui.publishStatus.innerText = `Uploading to ${platform}... ${Math.round(progress)}%`;
            }
        }, 600);
    },

    triggerLiveOverlay(type, message) {
        if (!this.ui.liveOverlay) return;
        
        const badge = document.createElement('div');
        badge.className = `overlay-badge overlay-${type}`;
        badge.innerText = message;
        
        this.ui.liveOverlay.appendChild(badge);
        
        // Remove after animation finishes
        setTimeout(() => badge.remove(), 3000);
    },

    updateCommentaryAssist(score, motion, noise) {
        if (!this.ui.commentaryAssistBox || !this.ui.commentaryCues) return;
        
        this.ui.commentaryAssistBox.classList.remove('hidden');
        
        let cue = "";
        if (score > 90) cue = "UNBELIEVABLE! This is a moment for the history books!";
        else if (score > 80 && motion > 70) cue = "Look at that speed! He's cutting through the defense like butter!";
        else if (score > 70 && noise > 50) cue = "The crowd is absolutely losing it! Can you hear that energy?";
        else if (motion > 80) cue = "Extreme physical intensity on the court right now!";
        else return; // Only show major cues
        
        const div = document.createElement('div');
        div.className = 'commentary-cue';
        div.innerHTML = `<strong>Assist:</strong> "${cue}"`;
        
        this.ui.commentaryCues.prepend(div);
        
        // Keep only last 5 cues
        if (this.ui.commentaryCues.children.length > 5) {
            this.ui.commentaryCues.lastElementChild.remove();
        }
    },

    async openLeagueDashboard() {
        this.ui.leagueModal.classList.remove('hidden');
        this.ui.gameComparisonChart.innerHTML = '<p style="color:var(--text-muted)">Loading comparison data...</p>';
        
        try {
            const res = await fetch(`${this.apiBase}/league_stats.php`);
            const data = await res.json();
            if (data.success) {
                this.renderLeagueDashboard(data);
            }
        } catch (err) {
            console.error("League Stats Error:", err);
        }
    },

    renderLeagueDashboard(data) {
        const { season_stats, games_comparison, top_players, trend } = data;

        // 1. High-Level Stats
        this.ui.seasonTotalScore.innerText = Math.round(season_stats.total_excitement).toLocaleString();
        this.ui.seasonAvgScore.innerText = season_stats.avg_intensity.toFixed(1);
        this.ui.seasonHighlights.innerText = season_stats.total_highlights;

        // 2. Game Comparison Chart
        this.ui.gameComparisonChart.innerHTML = '';
        games_comparison.forEach(game => {
            const row = document.createElement('div');
            row.className = 'comparison-bar-row';
            const pct = (game.peak_excitement / 100) * 100; // Assuming 100 is max
            row.innerHTML = `
                <div class="comparison-bar-info">
                    <span>${game.title}</span>
                    <span>Peak: ${parseFloat(game.peak_excitement).toFixed(1)}</span>
                </div>
                <div class="comparison-bar-container">
                    <div class="comparison-bar-fill" style="width: 0%" data-pct="${pct}"></div>
                </div>
            `;
            this.ui.gameComparisonChart.appendChild(row);
            // Trigger animation
            setTimeout(() => {
                row.querySelector('.comparison-bar-fill').style.width = pct + '%';
            }, 100);
        });

        // 3. Season Leaders
        this.ui.seasonLeadersList.innerHTML = '';
        Object.entries(top_players).forEach(([name, score], idx) => {
            const div = document.createElement('div');
            div.style = "display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.02);";
            div.innerHTML = `
                <span style="font-size:0.8rem; color:var(--text-primary)">
                   <span style="color:var(--accent-secondary); font-weight:bold; margin-right: 8px;">#${idx+1}</span> ${name}
                </span>
                <span style="font-size:0.8rem; color:var(--accent-primary)">${Math.round(score)} pts</span>
            `;
            this.ui.seasonLeadersList.appendChild(div);
        });

        // 4. Trend Chart
        this.ui.seasonTrendChart.innerHTML = '';
        if (trend.length > 0) {
            const maxScore = Math.max(...trend.map(t => t.avg_score));
            trend.forEach(t => {
                const bar = document.createElement('div');
                bar.className = 'trend-bar';
                const height = (t.avg_score / maxScore) * 80;
                bar.style.height = '0px';
                bar.setAttribute('data-label', t.game_date.split('-').slice(1).join('/'));
                bar.title = `Date: ${t.game_date}, Avg: ${parseFloat(t.avg_score).toFixed(1)}`;
                this.ui.seasonTrendChart.appendChild(bar);
                setTimeout(() => bar.style.height = height + 'px', 300);
            });
        } else {
            this.ui.seasonTrendChart.innerHTML = '<p style="color:gray; font-size:0.7rem;">Not enough data for trend.</p>';
        }
    },

    async upgradeTier(tier) {
        this.log(`Upgrading to ${tier} tier...`, "alert");
        this.state.userTier = tier;
        
        // Show success state
        if (this.ui.pricingModal) this.ui.pricingModal.classList.add('hidden');
        if (this.ui.earningsDashboard) this.ui.earningsDashboard.classList.remove('hidden');
        if (this.ui.userTierBadge) {
            this.ui.userTierBadge.innerText = tier;
            this.ui.userTierBadge.className = 'tier-badge ' + tier.toLowerCase();
        }

        // Simulating processing delay
        setTimeout(() => {
            alert(`🎉 Success! You are now on the ${tier} Tier.`);
        }, 500);
    },

    updateEarnings(score) {
        if (this.state.userTier === 'Free') return;
        
        // Simulating earnings: $0.10 for every score > 90, $0.05 for > 80
        let earnings = 0;
        if (score > 90) earnings = 0.10;
        else if (score > 80) earnings = 0.05;
        
        if (earnings > 0) {
            this.state.balance += earnings;
            if (this.ui.estBalance) {
                this.ui.estBalance.innerText = `$${this.state.balance.toFixed(2)}`;
            }
        }
    },

    formatTime(sec) {
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    },

    typeWriter(text, element) {
        element.innerHTML = "";
        let i = 0;
        const speed = 20; 
        function type() {
            if (i < text.length) {
                element.innerHTML += text.charAt(i);
                i++;
                setTimeout(type, speed);
            }
        }
        type();
    },

    // --- Library Features ---

    async fetchGames() {
        try {
            const res = await fetch(`${this.apiBase}/games_list.php`);
            const data = await res.json();
            if (data.success) {
                this.renderGamesList(data.games);
                this.ui.libraryModal.classList.remove('hidden');
            }
        } catch (e) {
            this.log("Error fetching games library: " + e.message, "alert");
        }
    },

    renderGamesList(games) {
        const grid = document.getElementById('gamesList');
        grid.innerHTML = '';
        
        if (games.length === 0) {
            grid.innerHTML = '<p style="color:var(--text-muted)">No analyzed games found.</p>';
            return;
        }

        games.forEach(g => {
            const date = new Date(g.game_date).toLocaleDateString();
            const peak = g.peak_excitement ? parseFloat(g.peak_excitement).toFixed(1) : 'N/A';
            
            const card = document.createElement('div');
            card.className = 'game-card';
            card.innerHTML = `
                <div class="game-title">${g.title}</div>
                <div class="game-meta">📅 ${date} • ⏱️ ${this.formatTime(g.duration)}</div>
                <div class="game-score">🔥 Peak Excitement: ${peak}</div>
            `;
            
            card.onclick = () => {
                this.loadGame(g.id);
                this.ui.libraryModal.classList.add('hidden');
            };
            
            grid.appendChild(card);
        });
    },

    async loadGame(id) {
        this.state.gameId = id;
        this.log(`Loading Game #${id} from archives...`);
        this.ui.uploadArea.classList.add('hidden');
        this.ui.videoWrapper.classList.remove('hidden'); // Show player (even if empty)
        
        // Hide controls that require video
        this.ui.startBtn.classList.add('hidden');
        this.ui.controlsArea.classList.remove('hidden');
        
        // Reset UI
        this.ui.highlights.innerHTML = '';
        this.ui.aiSummary.innerText = 'Loading...';
        
        await this.renderResults();
        this.log(`Game #${id} loaded successfully.`);
    }
};

window.app = app;
window.addEventListener('DOMContentLoaded', () => app.init());
