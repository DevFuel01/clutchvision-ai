<?php
// Simple Health Check
$urls = [
    'api/game_create.php',
    'api/events_log.php',
    'api/ai_analyze.php',
    'api/game_results.php'
];

foreach ($urls as $url) {
    echo "Checking $url... ";
    if (file_exists(__DIR__ . '/' . $url)) {
        echo "EXISTS. ";
        // Syntax Check
        $output = shell_exec("php -l " . __DIR__ . '/' . $url);
        if (strpos($output, 'No syntax errors') !== false) {
            echo "SYNTAX OK.\n";
        } else {
            echo "SYNTAX ERROR: $output\n";
        }
    } else {
        echo "MISSING.\n";
    }
}
