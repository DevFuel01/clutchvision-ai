# ClutchVision AI - Advanced Sports Intelligence Platform

ClutchVision AI is a **next-generation basketball analytics platform** that transforms raw game footage into actionable intelligence. Combining real-time signal processing with Google Gemini AI, it empowers creators, coaches, and leagues to capture, analyze, and monetize every clutch moment.

---

## 🚀 Core Features

### 1. Advanced Live Detection
- **🔴 Live Stream Support**: Real-time analysis of webcam or live stream inputs via `MediaDevices API`.
- **Instant Highlights**: High-intensity moments (Score > 85) are pushed to the UI instantly during processing.
- **Multimodal Analysis**: Analyzes crowd noise (Web Audio API) and motion intensity (Pixel-diffing) simultaneously.

### 2. Broadcaster & Commentary Suite
- **📺 Live Overlays**: Professional broadcast badges (🔥 CLUTCH, ⚡ ENERGY, 📈 MOMENTUM) flash dynamically over the video.
- **🎙️ Commentary Assist**: Real-time AI play-by-play cues provided to broadcasters to enhance storytelling.
- **Live Status**: Blinking indicator ensures synchronization with the game clock.

### 3. Social Hub & Distribution
- **📱 One-Click Sharing**: Instantly prepare clips for social media.
- **AI Captions**: Generates platform-specific, punchy captions for **TikTok**, **Reels**, and **X** using Gemini AI.
- **Clip Preview**: Integrated video player to review the exact highlight segment before publishing.

### 4. Player & League Analytics
- **🏆 Player Tagging**: Manually tag highlights with player names/numbers for session-wide tracking.
- **🔥 Player Heat Map**: Real-time leaderboard ranking players by cumulative excitement score.
- **📊 League Dashboard**: Multi-game comparison tools, season intensity trends, and aggregate "Season Excitement" metrics.

---

## 💎 Monetization & Membership

ClutchVision is built for scale with a tiered economic model:

| Tier | Features | Target Audience |
|------|----------|-----------------|
| **Free** | Core AI Detection, Standard Reports | Aspiring Creators |
| **Creator** | Social Hub, Earnings Dashboard, AI Captions | Pro Creators / YouTubers |
| **League** | League Analytics, Broadcast Tools, Licensing | Professional Leagues / Teams |

### 💰 Creator Revenue Share
Verified Creators earn revenue based on highlight engagement. A real-time **Earnings Dashboard** tracks estimated balance during analysis, rewarding "Clutch" and "Momentum Shift" detections.

---

## 🛠️ Technical Architecture

### Tech Stack
- **Frontend**: Vanilla JavaScript (ES6+), CSS3 (Modern Glassmorphism), HTML5.
- **Backend**: PHP 8.0+ Performance Layer.
- **Database**: MySQL 5.7+ (Highly indexed for telemetry speed).
- **AI Engine**: Google Gemini API (Dual Mode: AI Proxy & pattern-based Fallback).

### Key API Endpoints
- `api/ai_analyze.php`: The primary intelligence engine.
- `api/save_tags.php`: Manages player-specific analytics.
- `api/generate_caption.php`: AI caption generator.
- `api/league_stats.php`: Aggregate seasonal data aggregator.

---

## 📝 Setup & Installation

### Rapid Local Setup
1. Clone the repository into your web root (e.g., `xampp/htdocs/ClutchVision`).
2. Run `setup_db.php` to initialize the database schema and sample data.
3. Configure `db.php` with your local MySQL credentials.
4. **Gemini Key (Optional)**: Add your `GEMINI_API_KEY` in `api/config.php` for advanced AI narratives.

### Requirements
- **Hardware**: Webcam required for Live Mode.
- **Software**: Modern browser (Chrome/Edge recommended for pixel-diffing performance).

---

## 🎯 Our Mission
To democratize professional sports analytics so that every local court can feel like the NBA Finals.

**Built with ClutchVision AI** - *The AI that sees the clutch moments before everyone else.*

Contact me at ibrahimi107809@gmail.com or 07062616249