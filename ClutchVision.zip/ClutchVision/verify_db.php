<?php
require 'db.php';
try {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables found: " . implode(", ", $tables);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
