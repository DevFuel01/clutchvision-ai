<?php
$host = 'localhost';
$db   = 'clutchvision_ai';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // If DB doesn't exist yet, we might want to handle that gracefully or just fail.
    // For this MVP, we assume setup_db.php has been run.
    die("Database connection failed. Please run setup_db.php first. Error: " . $e->getMessage());
}
?>
