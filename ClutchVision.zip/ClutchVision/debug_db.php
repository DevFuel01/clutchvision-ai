<?php
require_once 'db.php';
try {
    $stmt = $pdo->query("DESCRIBE games");
    var_dump($stmt->fetchAll(PDO::FETCH_COLUMN));
} catch (Exception $e) {
    echo $e->getMessage();
}
