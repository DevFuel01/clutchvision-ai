<?php
require_once '../db.php';
require_once 'config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$hlId = $data['highlight_id'] ?? null;

if (!$hlId) {
    echo json_encode(['success' => false, 'error' => 'Missing highlight_id']);
    exit;
}

try {
    // Fetch highlight details
    $stmt = $pdo->prepare("SELECT h.*, g.title as game_title FROM highlights h JOIN games g ON h.game_id = g.id WHERE h.id = :id");
    $stmt->execute(['id' => $hlId]);
    $hl = $stmt->fetch();

    if (!$hl) {
        throw new Exception("Highlight not found");
    }

    $prompt = "You are a social media manager for a basketball team. Generate 3 short, punchy, and engaging social media captions for this highlight:
    
    Game: {$hl['game_title']}
    Time: {$hl['event_time']}s
    Label: {$hl['label']}
    Analysis: {$hl['explanation']}
    Player Tags: {$hl['player_tags']}
    Excitement Score: {$hl['score']}

    FORMAT:
    Return a JSON object with:
    {
       \"tiktok\": \"Caption with hashtags...\",
       \"reels\": \"Caption with hashtags...\",
       \"x\": \"Short caption with hashtags...\"
    }
    No markdown blocks, just the raw JSON.";

    $url = "https://generativelanguage.googleapis.com/v1/models/" . GEMINI_MODEL . ":generateContent?key=" . GEMINI_API_KEY;
    $payload = [
        "contents" => [["parts" => [["text" => $prompt]]]]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $json = json_decode($response, true);

    if (isset($json['candidates'][0]['content']['parts'][0]['text'])) {
        $text = $json['candidates'][0]['content']['parts'][0]['text'];
        $cleanJson = preg_replace('/```json\s*|\s*```/', '', $text);
        echo json_encode(['success' => true, 'captions' => json_decode($cleanJson, true)]);
    } else {
        throw new Exception("AI failed to generate captions");
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
