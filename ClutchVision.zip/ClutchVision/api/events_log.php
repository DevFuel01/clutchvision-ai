<?php
require_once '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['game_id']) || empty($input['events'])) {
    echo json_encode(['success' => false, 'error' => 'Missing game_id or events']);
    exit;
}

try {
    $gameId = $input['game_id'];
    $events = $input['events'];

    $sql = "INSERT INTO events (game_id, timestamp, quarter, crowd_noise_level, motion_intensity, scoring_event, excitement_score) VALUES (:game_id, :timestamp, :quarter, :crowd_noise, :motion, :scoring, :score)";
    $stmt = $pdo->prepare($sql);

    $savedCount = 0;
    foreach ($events as $event) {
        $stmt->execute([
            'game_id' => $gameId,
            'timestamp' => $event['timestamp'],
            'quarter' => $event['quarter'] ?? 1,
            'crowd_noise' => $event['crowd_noise'],
            'motion' => $event['motion_intensity'],
            'scoring' => $event['scoring_event'] ? 1 : 0,
            'score' => $event['excitement_score']
        ]);
        $savedCount++;
    }

    echo json_encode(['success' => true, 'saved_count' => $savedCount]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
