<?php
require_once '../db.php';

header('Content-Type: application/json');

if (empty($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'Missing ID']);
    exit;
}

$gameId = $_GET['id'];

try {
    // Get Game
    $stmt = $pdo->prepare("SELECT * FROM games WHERE id = :id");
    $stmt->execute(['id' => $gameId]);
    $game = $stmt->fetch();

    if (!$game) {
        echo json_encode(['success' => false, 'error' => 'Game not found']);
        exit;
    }

    // Get Highlights
    $stmt = $pdo->prepare("SELECT * FROM highlights WHERE game_id = :id ORDER BY rank_order ASC");
    $stmt->execute(['id' => $gameId]);
    $highlights = $stmt->fetchAll();

    // Get Summary
    $stmt = $pdo->prepare("SELECT summary_text, created_at FROM ai_summaries WHERE game_id = :id ORDER BY id DESC LIMIT 1");
    $stmt->execute(['id' => $gameId]);
    $summary = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'game' => $game,
        'highlights' => $highlights,
        'summary' => $summary
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
