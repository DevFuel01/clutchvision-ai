<?php
require_once '../db.php';

header('Content-Type: application/json');

try {
    // 1. Seasonal Aggregate Excitement
    $stmt = $pdo->query("SELECT SUM(score) as total_score, COUNT(*) as total_highlights FROM highlights");
    $aggregates = $stmt->fetch();

    // 2. Games Comparison (Top 5 most exciting games)
    $stmt = $pdo->query("
        SELECT g.id, g.title, g.game_date, 
               MAX(h.score) as peak_excitement,
               AVG(h.score) as avg_excitement,
               COUNT(h.id) as highlights_count
        FROM games g
        LEFT JOIN highlights h ON g.id = h.game_id
        GROUP BY g.id
        ORDER BY peak_excitement DESC
        LIMIT 10
    ");
    $games = $stmt->fetchAll();

    // 3. Top Players (Season-wide)
    $stmt = $pdo->query("SELECT id, player_tags, score FROM highlights WHERE player_tags != ''");
    $allTaggedHighlights = $stmt->fetchAll();

    $playerScores = [];
    foreach ($allTaggedHighlights as $hl) {
        $tags = explode(',', $hl['player_tags']);
        foreach ($tags as $tag) {
            $tag = trim($tag);
            if (!$tag) continue;
            if (!isset($playerScores[$tag])) $playerScores[$tag] = 0;
            $playerScores[$tag] += (float)$hl['score'];
        }
    }
    arsort($playerScores);
    $topPlayers = array_slice($playerScores, 0, 10, true);

    // 4. Season Trend (Avg excitement by date)
    $stmt = $pdo->query("
        SELECT g.game_date, AVG(h.score) as avg_score
        FROM games g
        JOIN highlights h ON g.id = h.game_id
        GROUP BY g.game_date
        ORDER BY g.game_date ASC
    ");
    $trend = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'season_stats' => [
            'total_excitement' => (float)($aggregates['total_score'] ?? 0),
            'total_highlights' => (int)($aggregates['total_highlights'] ?? 0),
            'avg_intensity' => $aggregates['total_highlights'] > 0 ? (float)($aggregates['total_score'] / $aggregates['total_highlights']) : 0
        ],
        'games_comparison' => $games,
        'top_players' => $topPlayers,
        'trend' => $trend
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
