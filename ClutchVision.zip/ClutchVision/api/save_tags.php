<?php
require_once '../db.php';
header('Content-Type: application/json');

// Get input
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['highlight_id']) || !isset($data['tags'])) {
    echo json_encode(['success' => false, 'error' => 'Missing ID or Tags']);
    exit;
}

$hlId = $data['highlight_id'];
$tags = trim($data['tags']);

try {
    // Basic validation
    // Ensure tags are comma-separated clean strings
    $cleanTags = array_map('trim', explode(',', $tags));
    $cleanTagsStr = implode(', ', array_filter($cleanTags)); // remove empty

    $stmt = $pdo->prepare("UPDATE highlights SET player_tags = :tags WHERE id = :id");
    $stmt->execute(['tags' => $cleanTagsStr, 'id' => $hlId]);

    echo json_encode(['success' => true, 'tags' => $cleanTagsStr]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
