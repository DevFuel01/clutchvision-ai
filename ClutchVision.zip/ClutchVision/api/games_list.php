<?php
require_once '../db.php';

header('Content-Type: application/json');

try {
    // Fetch all games with their created dates and calculated stats
    // We calculate Max Excitement from the events table for comparison
    $sql = "
        SELECT 
            g.id, 
            g.title, 
            g.game_date, 
            g.duration, 
            g.created_at,
            (SELECT MAX(excitement_score) FROM events WHERE game_id = g.id) as peak_excitement
        FROM games g
        ORDER BY g.created_at DESC
    ";

    $stmt = $pdo->query($sql);
    $games = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'games' => $games]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
