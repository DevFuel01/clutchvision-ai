<?php
require_once '../db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['title'])) {
    echo json_encode(['success' => false, 'error' => 'Title is required']);
    exit;
}

try {
    // Optional fields
    $gameDate = !empty($input['game_date']) ? $input['game_date'] : date('Y-m-d');
    $duration = !empty($input['duration']) ? intval($input['duration']) : 0;

    $stmt = $pdo->prepare("INSERT INTO games (title, game_date, duration) VALUES (:title, :gdate, :dur)");
    $stmt->execute([
        'title' => $input['title'],
        'gdate' => $gameDate,
        'dur' => $duration
    ]);
    $gameId = $pdo->lastInsertId();

    echo json_encode(['success' => true, 'game_id' => $gameId]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
