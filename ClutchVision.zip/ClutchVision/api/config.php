<?php
// ClutchVision AI Configuration YOUR_GEMINI_API_KEY_HERE
// Get your API Key from: https://aistudio.google.com/app/apikey

define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE');

// Model Configuration
define('GEMINI_MODEL', 'gemini-2.5-flash'); // Confirmed working model
define('GEMINI_API_VERSION', 'v1'); // Use stable v1 API
