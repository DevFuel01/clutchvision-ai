<?php
require_once 'api/config.php';

echo "Testing Gemini API Connection...\n\n";
echo "API Key: " . substr(GEMINI_API_KEY, 0, 10) . "...\n";
echo "Model: " . GEMINI_MODEL . "\n\n";

$url = "https://generativelanguage.googleapis.com/v1/models/" . GEMINI_MODEL . ":generateContent?key=" . GEMINI_API_KEY;

$data = [
    "contents" => [
        [
            "parts" => [
                ["text" => "Say 'Hello from ClutchVision AI' in exactly 5 words."]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

echo "HTTP Status: $httpCode\n";
echo "Response:\n";
echo $response . "\n\n";

if ($httpCode === 200) {
    $json = json_decode($response, true);
    if (isset($json['candidates'][0]['content']['parts'][0]['text'])) {
        echo "✅ SUCCESS! AI Response: " . $json['candidates'][0]['content']['parts'][0]['text'] . "\n";
    }
} else {
    echo "❌ FAILED. Check the error above.\n";
}

curl_close($ch);
