<?php
require_once 'db.php';

try {
    // Add quarter and score columns to highlights table
    $sql = "
        ALTER TABLE highlights
        ADD COLUMN quarter INT DEFAULT 1,
        ADD COLUMN score DECIMAL(5,2) DEFAULT 0.00;
    ";

    $pdo->exec($sql);
    echo "Schema updated successfully: Added quarter and score to highlights table.";
} catch (PDOException $e) {
    echo "Error updating schema: " . $e->getMessage();
}
