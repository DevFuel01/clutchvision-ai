<?php
require 'db.php';

try {
    echo "Updating database schema...\n";

    // Add game_date column
    try {
        $pdo->exec("ALTER TABLE games ADD COLUMN game_date DATE DEFAULT NULL");
        echo "Added game_date column.\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "game_date column already exists.\n";
        } else {
            echo "Error adding game_date: " . $e->getMessage() . "\n";
        }
    }

    // Add duration column
    try {
        $pdo->exec("ALTER TABLE games ADD COLUMN duration INT DEFAULT 0");
        echo "Added duration column.\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "duration column already exists.\n";
        } else {
            echo "Error adding duration: " . $e->getMessage() . "\n";
        }
    }

    echo "Schema update complete.";
} catch (Exception $e) {
    echo "Critical Error: " . $e->getMessage();
}
